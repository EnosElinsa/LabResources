#define _GNU_SOURCE
#include "cachelab.h"
#include <getopt.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAX_FILENAME_LENGTH 100

static int s; // Number of set index bits(S = 2 ^ s is the number of sets)
static int E; // Associativity(number of lines per set)
static int b; // Number of block bits(B = 2 ^ b is the block size)
static int S; // Number of sets
static int hit_count = 0;
static int miss_count = 0;
static int eviction_count = 0;
static char* tracefile_directory;

// A double linkedList node to simulate a line in a set
typedef struct Line {
    unsigned tag;
    struct Line* prev;
    struct Line* next;
} Line;

// Use a double linkedList to simulate and arrange a set in the cache
typedef struct LRU {
    Line* head;
    Line* tail;
    int size;
} LRU;

static LRU* cache;

void parseCommandLineArguments(int argc, char** argv);
void intializeCache();
void insertAtHead(LRU* current_LRU, Line* new_line);
void delete(LRU* current_LRU, Line* line_to_be_deleted);
Line* findByTag(LRU* current_LRU, unsigned target_tag);
void update(unsigned address);
void simulate();

int main(int argc, char** argv)
{
    parseCommandLineArguments(argc, argv);
    intializeCache();
    simulate();
    printSummary(hit_count, miss_count, eviction_count);
    return 0;
}

void parseCommandLineArguments(int argc, char** argv) {
    int option;
    tracefile_directory = (char*)malloc(MAX_FILENAME_LENGTH * sizeof(char));
    while ((option = getopt(argc, argv, "s:E:b:t:")) != -1) {
        switch(option) {
        case 's': s = atoi(optarg);
        case 'E': E = atoi(optarg);
        case 'b': b = atoi(optarg);
        case 't': strcpy(tracefile_directory, optarg);
        }
    }
    S = 1 << s;
}

void intializeCache() {
    cache = (LRU*)malloc(S * sizeof(LRU));
    for (int set_index = 0; set_index < S; set_index++) {
        LRU* current_LRU = &cache[set_index];
        current_LRU->head = (Line*)malloc(sizeof(Line));
        current_LRU->tail = (Line*)malloc(sizeof(Line));

        current_LRU->head->next = current_LRU->tail;
        current_LRU->tail->prev = current_LRU->head;

        current_LRU->head->prev = NULL;
        current_LRU->tail->next = NULL;

        cache[set_index].size = 0;
    }
}

void insertAtHead(LRU* current_LRU, Line* new_line) {
    new_line->next = current_LRU->head->next;
    new_line->prev = current_LRU->head;
    current_LRU->head->next->prev = new_line;
    current_LRU->head->next       = new_line;
    current_LRU->size++;
}

void delete(LRU* current_LRU, Line* line_to_be_deleted) {
    line_to_be_deleted->prev->next = line_to_be_deleted->next;
    line_to_be_deleted->next->prev = line_to_be_deleted->prev;
    current_LRU->size--;
}

Line* findByTag(LRU* current_LRU, unsigned target_tag) {
    Line* current_line = current_LRU->head->next;
    while (current_line != current_LRU->tail) {
        if (current_line->tag == target_tag) {
            return current_line;
        }
        current_line = current_line->next;
    }
    return NULL;
}

void update(unsigned address) {
    unsigned tag = address >> (s + b);
    unsigned set_index = (address >> b) & (0xFFFFFFFF >> (32 - s));
    LRU* current_LRU = &cache[set_index];
    Line* target_line = findByTag(current_LRU, tag);
    if (target_line != NULL) {
        hit_count++;
        if (current_LRU->head->next != target_line) {
            delete(current_LRU, target_line);
            insertAtHead(current_LRU, target_line);
        }
    }
    else {
        miss_count++;

        Line* new_line = (Line*)malloc(sizeof(Line));
        new_line->next = NULL;
        new_line->prev = NULL;
        new_line->tag = tag;

        if (current_LRU->size == E) {
            delete(current_LRU, current_LRU->tail->prev);
            eviction_count++;
        }
        insertAtHead(current_LRU, new_line);
    }
}

void simulate() {
    FILE* fp = fopen(tracefile_directory, "r");
    char operation;
    unsigned address;
    int size;
    while(fscanf(fp, "%c %x, %d", &operation, &address, &size) > 0) {
        switch (operation)
        {
        case 'L': update(address); break;
        case 'M': update(address);
        case 'S': update(address); break;
        }
    }
}


